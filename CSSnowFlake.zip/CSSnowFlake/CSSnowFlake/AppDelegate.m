//
//  AppDelegate.m
//  CSSnowFlake
//
//  Created by Andersen on 2020/4/1.
//  Copyright © 2020 Andersen. All rights reserved.
//

#import "AppDelegate.h"
#import "CSSnowIDFactory.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [self fetchSnowID];
    return YES;
}

- (void)fetchSnowID
{
    CSSnowIDFactory *snowFactory = [CSSnowIDFactory shareFactory];

    for (int i = 0; i<200; i++) {
        NSLog(@"snow ID: %ld",[snowFactory snowFlakeID]);
    }
}

@end
