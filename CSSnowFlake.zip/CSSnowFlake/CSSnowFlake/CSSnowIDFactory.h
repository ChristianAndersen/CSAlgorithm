//
//  CSSnowIDFactory.h
//  DJReader
//
//  Created by Andersen on 2020/3/31.
//  Copyright © 2020 Andersen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSSnowIDFactory : NSObject
+ (CSSnowIDFactory*)shareFactory;
- (long)snowFlakeID;//返回自增ID
@end

NS_ASSUME_NONNULL_END
